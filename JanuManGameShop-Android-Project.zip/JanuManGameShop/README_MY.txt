JANU MAN GAME SHOP — Android Project Starter
============================================

ဒီ project က ရိုးရှင်းတဲ့ Game Shop demo ဖြစ်ပါတယ်။ ဂိမ်းရွေးချယ်ခြင်း၊ ပက်ကေ့ချ်/ဈေးနှုန်းထည့်ခြင်း၊ Player ID နှင့် ဆက်သွယ်ရန်အချက်အလက်ထည့်ခြင်း၊ KBZPay/WavePay ရွေးခြင်း၊ အော်ဒါစာသားပြုလုပ်ပြီး ကူးယူခြင်းတို့ ပါဝင်ပါတယ်။

အရေးကြီးသော ကန့်သတ်ချက်များ
- ဒီ ZIP ထဲမှာ APK ဖိုင်မပါသေးပါ။ Android project source files ပါဝင်ပါတယ်။
- ဈေးနှုန်းကို ဆိုင်ရှင်က ကိုယ်တိုင်ထည့်ရမည့် demo ဖြစ်ပါတယ်။
- KBZPay/WavePay အလိုအလျောက်ငွေပေးချေမှု အတည်ပြုစနစ် မချိတ်ဆက်ရသေးပါ။ ငွေလက်ခံရရှိမှုကို ကိုယ်တိုင်စစ်ဆေးပြီးမှ အော်ဒါအတည်ပြုပါ။
- ဂိမ်းအကောင့် password/OTP ကို customer ထံမှ မတောင်းပါနှင့်။
- အော်ဒါများကို server/database သို့ မပို့သေးပါ။ အော်ဒါစာသားကို ပြုလုပ်ပြီး clipboard ထဲကူးယူရန်သာဖြစ်သည်။

ဖုန်းတစ်လုံးတည်းနဲ့ APK ဆောက်ရန်
1. ZIP ဖိုင်ကို Android ဖုန်းထဲမှာ ဖြည်ပါ။
2. Android ဖုန်းပေါ်မှာ Gradle project build လုပ်နိုင်သော IDE/builder ကို တပ်ဆင်ပြီး project folder ကိုဖွင့်ပါ။ AndroidIDE ကဲ့သို့ tool တစ်ခု ရရှိနိုင်မှုနှင့် Android/Gradle compatibility ကို စစ်ဆေးနိုင်ပါတယ်။
3. JDK 17 နှင့် Android SDK လိုအပ်နိုင်ပါတယ်။ Gradle sync ပြီး build လုပ်ပါ။
4. `assembleDebug` task သို့မဟုတ် IDE ရဲ့ Build APK လုပ်ဆောင်ချက်ကို ရွေးပါ။
5. APK output ပုံမှန်အားဖြင့် `app/build/outputs/apk/debug/app-debug.apk` မှာ ရှိနိုင်ပါတယ်။
6. ကိုယ်တိုင်စမ်းသပ်ပြီးမှသာ ယုံကြည်ရသော စက်တွင် install လုပ်ပါ။ Android security prompt များကို စစ်ဆေးပါ။

ကွန်ပျူတာရလာပါက Android Studio နဲ့ project folder ကိုဖွင့်ပြီး Gradle sync လုပ်ကာ Build > Build APK(s) ကိုရွေးနိုင်ပါတယ်။

ပြင်ဆင်ရန်
- `app/src/main/assets/index.html` ထဲမှာ ဂိမ်းအမျိုးအစား၊ UI၊ စာသားများကို ပြင်နိုင်ပါတယ်။
- KBZPay/WavePay ငွေလက်ခံရန် တရားဝင် merchant နည်းလမ်း သို့မဟုတ် ကိုယ်ပိုင်လုံခြုံသော လက်ခံ QR ကို သီးခြားပြင်ဆင်ပါ။ ဒီ starter မှာ အကောင့်နံပါတ်၊ QR၊ API key မပါပါ။
- အများသုံးဆိုင်အဖြစ် လွှင့်မည်ဆိုပါက server/database, order tracking, privacy notice, support contact နှင့် verified payment confirmation ထပ်ထည့်ရန်လိုပါတယ်။
